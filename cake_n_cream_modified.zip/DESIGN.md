---
name: Artisanal Elegance
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#4d4635'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#7f7663'
  outline-variant: '#d0c5af'
  surface-tint: '#735c00'
  primary: '#735c00'
  on-primary: '#ffffff'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#e9c349'
  secondary: '#635e53'
  on-secondary: '#ffffff'
  secondary-container: '#e9e2d3'
  on-secondary-container: '#696458'
  tertiary: '#5d5f5f'
  on-tertiary: '#ffffff'
  tertiary-container: '#b2b3b3'
  on-tertiary-container: '#434546'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#e9e2d3'
  secondary-fixed-dim: '#cdc6b8'
  on-secondary-fixed: '#1e1b13'
  on-secondary-fixed-variant: '#4b463c'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Montserrat
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Montserrat
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1200px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style

The design system for the bakery is rooted in a **Minimalist** and **Corporate Modern** aesthetic, tailored for a premium, high-end culinary experience. It aims to evoke a sense of refined indulgence, craftsmanship, and exclusivity. 

By leveraging generous whitespace and a restricted, warm palette, the UI serves as a quiet stage for the product photography—treating each cake as a piece of fine art. The emotional response is one of trust and sophistication, ensuring that the digital experience mirrors the artisanal quality of the physical bakery.

## Colors

The color palette is inspired by the raw ingredients of a premium bakery: rich cream and pure white.
- **Primary (Soft Gold):** Used sparingly for interactive elements, call-to-actions, and decorative dividers to signify luxury.
- **Secondary (Rich Cream):** The primary surface color, providing a warmer, more inviting feel than pure white.
- **Tertiary (White):** Used for nested containers, input fields, and to create crisp contrast against the cream background.
- **Neutral:** A deep, off-black is used for typography to ensure maximum legibility without the harshness of true black.

## Typography

The typography strategy relies on the contrast between the classic, high-contrast Serif (Playfair Display) and the geometric, airy Sans-Serif (Montserrat). 

Headlines use Playfair Display to convey heritage and sophistication. Body copy uses Montserrat with increased line-height and letter-spacing to maintain an "airy" and readable feel. Labels and buttons are set in uppercase Montserrat to provide a modern, structural counterpoint to the fluid serif headings.

## Layout & Spacing

This design system utilizes a **Fixed Grid** model for desktop to ensure a curated, editorial feel, transitioning to a fluid model for mobile devices.

- **Desktop:** 12-column grid with a 1200px max-width. Margins are intentionally wide (64px) to emphasize the premium nature of the brand.
- **Mobile:** 4-column fluid grid.
- **Rhythm:** An 8px base unit drives all padding and margin decisions. For luxury appeal, vertical spacing between sections should be aggressive (e.g., 128px or 160px) to allow the content to "breathe."

## Elevation & Depth

Depth is created through **Tonal Layers** and **Ambient Shadows**. 

Avoid heavy dropshadows. Instead, use soft, diffused shadows with a low opacity (5-10%) and a hint of the gold primary color in the shadow's tint. This creates a "lifted" effect for cards and modals that feels more like natural studio lighting. 

Secondary depth is achieved by placing White (#FFFFFF) cards on the Rich Cream (#FDF5E6) background, creating a subtle hierarchical distinction without the need for borders.

## Shapes

To maintain a sophisticated and architectural feel, the design system uses **Soft** roundedness. 

A corner radius of 4px is applied to buttons and input fields, providing a slight "human" touch while remaining sharp enough to feel precise and professional. Cards may use `rounded-lg` (8px) to feel more distinct from the page background.

## Components

### Buttons
Primary buttons feature a Gold (#D4AF37) background with White text, using uppercase Montserrat for the label. Secondary buttons are outlined in Gold with a transparent background.

### Input Fields
Fields use a White background with a very subtle 1px border in a muted gold or light grey. Focus states should transition the border to the Primary Gold color.

### Cards
Cards for product listings (cakes/pastries) should have no visible border. Use the soft ambient shadow and a White background against the Cream page background. Images should always be the focal point, occupying the top 70% of the card.

### Dividers
Use 1px horizontal lines in Gold (#D4AF37) at 30% opacity to separate sections without breaking the visual flow.

### Chips/Tags
Used for dietary labels (e.g., "Gluten Free", "Vegan"). These should be pill-shaped with a Cream background and Gold text to remain subtle and non-intrusive.